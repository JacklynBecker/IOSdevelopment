//
//  HomeViewController.swift
//  AspireApp
//
//  Created by Jacky Becker on 2024-12-03.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class HomeViewController: UIViewController {

    
    @IBOutlet weak var TextViewWaiver: UITextView!
    
    @IBOutlet weak var visitorPassLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        visitorPassLabel.text = ""
        getData()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func getData(){
        Task {
          do {
              
              let db  = Firestore.firestore()
              let userUID = Auth.auth().currentUser?.uid
              
            let documentSnapshot = try await db.collection("users").document(userUID!).getDocument()
            if let data = documentSnapshot.data() {

                if (data["visitorPass"] as! Bool){
                    visitorPassLabel.text = "Yes"
                }
            }
          }
          catch {
            print(error.localizedDescription)
          }
        }
    }
   

}
